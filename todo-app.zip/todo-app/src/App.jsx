import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "./App.css";
import { useState } from "react";

function App() {
  const [text, setText] = useState("");
  const [date, setDate] = useState("");
  const [todos, setTodos] = useState([]);

  const onchange = (event) => {
    setText(event.target.value);
  };

  const onchangedate = (event) => {
    setDate(event.target.value);
  };

  const finalclick = () => {
    const newTodo = { text, date };
    setTodos([...todos, newTodo]);

    setText("");
    setDate("");
  };

  const deleteTodo = (index) => {
    setTodos(todos.filter((_, i) => i !== index));
  };

  return (
    <>
      <center>
        <h3>Todo App</h3>
        <div>
          <Container>
            <Row>
              <Col>
                <input
                  id="text"
                  type="text"
                  placeholder="Enter todo!"
                  value={text}
                  onChange={onchange}
                />
              </Col>

              <Col>
                <input
                  id="date"
                  type="date"
                  value={date}
                  onChange={onchangedate}
                />
              </Col>

              <Col>
                <button
                  id="button"
                  type="button"
                  className="btn btn-success"
                  onClick={finalclick}
                >
                  Add
                </button>
              </Col>
            </Row>
          </Container>
        </div>
      </center>

      {/* Render Logic */}
      <center>
        <Container id="render-container">
          {todos.map((item, idx) => (
            <Row key={idx} className="mt-3">
              <Col id="text-data">{item.text}</Col>
              <Col id="date-data">{item.date}</Col>
              <Col id="delete-btn">
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={() => deleteTodo(idx)}
                >
                  Delete
                </button>
              </Col>
            </Row>
          ))}
        </Container>
      </center>
    </>
  );
}

export default App;